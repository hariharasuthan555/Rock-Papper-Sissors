import sys

score=0

# Define colors
YELLOW = "\033[93m"
GREEN = "\033[92m"
RESET = "\033[0m"
RED = "\033[91m"
# Reset to default color

rock = f'''{YELLOW}
    _____
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = f'''{YELLOW}
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = f'''{YELLOW}
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

import random

def play(user_choice):
    global score
    print("Your Choice:")
    if user_choice == 0:
        print(rock)
    elif user_choice == 1:
        print(paper)
    elif user_choice == 2:
        print(scissors)
    else:
        print("Wrong Choice!")
        sys.exit()

    print("computer chooses:\n")
    computer_choice = random.randint(0, 2)
    if computer_choice == 0:
        print(rock)
    elif computer_choice == 1:
        print(paper)
    else:
        print(scissors)

    if user_choice == 0 and computer_choice == 0:
        print(f"\n{GREEN}It's a draw!")
    elif user_choice == 0 and computer_choice == 1:
        print(f"\n{GREEN}Computer Won...")
    elif user_choice == 0 and computer_choice == 2:
        print(f"\n{GREEN}You Won!")
        score+=1
    elif user_choice == 1 and computer_choice == 0:
        print(f"\n{GREEN}You Won!")
        score+=1
    elif user_choice == 1 and computer_choice == 1:
        print(f"\n{GREEN}It's a draw!")
    elif user_choice == 1 and computer_choice == 2:
        print(f"\n{GREEN}Computer Won...")
    elif user_choice == 2 and computer_choice == 0:
        print(f"\n{GREEN}Computer Won...")
    elif user_choice == 2 and computer_choice == 1:
        print(f"\n{GREEN}You Won!")
        score+=1
    else:
        print(f"\n{GREEN}It's a draw!")
    print(f"Score:{score}")

is_game0n=True
user=""
print(f"{RED}Welcome to Rock Papper Sissors \nCreated By: Hari Ravendran")
user_choice= int(input(f"\n\n{GREEN}What do you choose? Type 0 for Rock, 1 for Paper or 2 for Scissors:"))
if user_choice>3:
    print("Wrong Entry...")
    is_game0n=False

while is_game0n:
    play(user_choice)
    user=input(f"{GREEN}Click 'E' to exit or any other key to play again:").lower()
    if user != 'e':
        user_choice = int(input(f"{GREEN}What do you choose? Type 0 for Rock, 1 for Paper or 2 for Scissors."))
        if user_choice > 3:
            print(f"{GREEN}Wrong Entry...")
            is_game0n = False
    else:
        is_game0n=False

print(f"\n{RED}Game Ended. Enter any key to exit.")
input()